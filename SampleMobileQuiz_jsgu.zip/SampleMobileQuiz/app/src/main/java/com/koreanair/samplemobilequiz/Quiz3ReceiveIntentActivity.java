package com.koreanair.samplemobilequiz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Quiz3ReceiveIntentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz3_receive_intent);

        //TODO: Quiz3. 사용자의 입력을 다음 창으로 전달하기
        TextView textView1 = (TextView)findViewById(R.id.tv_username);
        TextView textView2 = (TextView)findViewById(R.id.tv_pwd);

        Bundle intent = getIntent().getExtras();
        textView1.setText(intent.getString("Username"));
        textView2.setText(intent.getString("Password"));
        //TODO: Quiz3. 사용자의 입력을 다음 창으로 전달하기
    }
}
